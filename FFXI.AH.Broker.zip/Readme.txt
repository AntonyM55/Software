FFXI.AH.PriceGrabber:
This program will connect to http://www.ffxiah.com and return active prices from the Bahamut Server. 
It stores the information in PriceList.xml
It Requires HTMLAgilityPack.DLL to run (from Codeplex)
Settings (in FFXI.AH.PriceGrabber.exe.config)
	Web_Links - List of the diffrent item types.
	Web_FFXIAHURL - URL to connect to.
	ErrorMode - set to 0, if there is a problem, exit out. 1 will cancel that item type but continue.
	OutputFileName -  the File to save that fun stuff to. (Default: PriceList.xml)

Usage: If you want updated Price Info, Run once a day / Week.	

FFXI.AH.Broker:
This Program serves two jobs. First it will add items from the PriceList to the auction house. Secondly it will buy items that are cheaper than the price history and put the money in your delivery box. 
It Requires MySql.Data.dll
Settings (in FFXI.AH.Broker.exe.Config)
	PriceList - The List of Items (and Buy/Sell Prices) to sell in the auction House. Created with PriceGrabber.
	PriceListOptional - Some items have a value of 0 for the price. the system will ignore this items.  Add them here with a good price to sell those items.
	PriceCutoff -  Min Gil to sell the item. Meaning if the Price is less than PriceCutoff, do not try to put it in the Auction House.
	MySQL_ConnectionString -  This is where you put your relevant MySql info. port 3306 is assumed. If you need it changed, let me know.
 	MySQL_AuctionTable - the Auction House table in SQL.
	MaxItemCount - I should have named this diffrent but oh well. This is the number of Items that the AuctionMoogle [:)] will keep in the auction house at any given time. So if sombody buys somthing, the program will add it back in up to the max number.
	SellerName -  the name of the Seller.
	
Command Line:
	once - Will only run once and then exit.
	dump - will delete everything in the auction_house table and start from fresh. this is good to do if its your first run.

The program is ment to run all the time, and executes every minute (buying and selling). if you update the Pricelist, then restart Broker to use the new values.	


Note: if you ran the other auction program, use the dump command or else the delevery box for that auction sender will get full and I don't know if it will cause an error.
